<?php
/**
 * Paintora REST API - Admin Endpoint
 *
 * Endpoints:
 * GET  /api/admin.php?action=stats
 * POST /api/admin.php?action=login
 * POST /api/admin.php?action=logout
 */

require_once __DIR__ . '/../utils/response.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../utils/auth.php';

setCorsHeaders();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? trim($_GET['action']) : '';

if ($method === 'GET') {

    if ($action === 'stats') {
        requireAdmin();
        handleStats($db);
    } else {
        sendError(
            "Unknown admin GET action.",
            "INVALID_ACTION",
            400
        );
    }

} elseif ($method === 'POST') {

    if ($action === 'login') {
        handleLogin($db);

    } elseif ($action === 'logout') {
        clearAuthSession();

        sendSuccess(
            "Admin logged out successfully.",
            null,
            200
        );

    } else {
        sendError(
            "Unknown admin POST action.",
            "INVALID_ACTION",
            400
        );
    }

} else {

    sendError(
        "Method {$method} not supported.",
        "METHOD_NOT_ALLOWED",
        405
    );
}


/**
 * Admin Dashboard Statistics
 */
function handleStats($db)
{
    $svcStmt = $db->query(
        "SELECT COUNT(*) AS total_services FROM services"
    );

    $totalServices = (int)$svcStmt->fetch()['total_services'];


    $bookStmt = $db->query("
        SELECT
            COUNT(*) AS total_bookings,

            SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END)
                AS pending_bookings,

            SUM(CASE WHEN status = 'Confirmed' THEN 1 ELSE 0 END)
                AS confirmed_bookings,

            SUM(CASE WHEN status = 'In Progress' THEN 1 ELSE 0 END)
                AS in_progress_bookings,

            SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END)
                AS completed_bookings,

            SUM(CASE WHEN status = 'Cancelled' THEN 1 ELSE 0 END)
                AS cancelled_bookings

        FROM bookings
    ");

    $bookData = $bookStmt->fetch();


    $revStmt = $db->query("
        SELECT COALESCE(SUM(s.price), 0) AS total_revenue
        FROM bookings b
        JOIN services s ON b.service_id = s.id
        WHERE b.status IN (
            'Confirmed',
            'In Progress',
            'Completed'
        )
    ");

    $revData = $revStmt->fetch();


    $stats = [
        'total_services'       => $totalServices,
        'total_bookings'       => (int)($bookData['total_bookings'] ?? 0),
        'pending_bookings'     => (int)($bookData['pending_bookings'] ?? 0),
        'confirmed_bookings'   => (int)($bookData['confirmed_bookings'] ?? 0),
        'in_progress_bookings' => (int)($bookData['in_progress_bookings'] ?? 0),
        'completed_bookings'   => (int)($bookData['completed_bookings'] ?? 0),
        'cancelled_bookings'   => (int)($bookData['cancelled_bookings'] ?? 0),
        'estimated_revenue'    => (float)($revData['total_revenue'] ?? 0)
    ];

    sendSuccess(
        "Admin dashboard statistics fetched successfully.",
        $stats,
        200
    );
}


/**
 * Admin Login
 */
function handleLogin($db)
{
    $input = getJsonInput();

    $email = isset($input['email'])
        ? trim($input['email'])
        : '';

    $password = isset($input['password'])
        ? trim($input['password'])
        : '';


    // Required fields
    if ($email === '' || $password === '') {
        sendError(
            "Email and password are both required.",
            "VALIDATION_ERROR",
            422
        );
    }


    // Normal email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        sendError(
            "Please enter a valid email address.",
            "VALIDATION_ERROR",
            422
        );
    }


    // Find admin in database
    $stmt = $db->prepare("
        SELECT id, name, email, password
        FROM admins
        WHERE email = :email
        LIMIT 1
    ");

    $stmt->execute([
        ':email' => $email
    ]);

    $admin = $stmt->fetch();


    // Check credentials
    if (
        !$admin ||
        !password_verify($password, $admin['password'])
    ) {
        sendError(
            "Invalid email or password. Please try again.",
            "AUTH_FAILED",
            401
        );
    }


    // Start session
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    session_regenerate_id(true);

    $_SESSION['admin_id'] = (int)$admin['id'];

    unset($_SESSION['customer_id']);


    // Send only safe admin information
    $profile = [
        'id'    => (int)$admin['id'],
        'name'  => $admin['name'],
        'email' => $admin['email']
    ];


    sendSuccess(
        "Admin authenticated successfully.",
        $profile,
        200
    );
}
