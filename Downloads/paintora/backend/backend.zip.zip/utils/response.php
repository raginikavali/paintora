<?php
/**
 * Paintora API Response Helper
 * Formats all API output as uniform JSON responses with proper HTTP status codes.
 */

// Suppress raw error display in output; capture all errors in logs
ini_set('display_errors', '0');
error_reporting(E_ALL);

// Start output buffering so stray warnings or whitespace cannot precede JSON
if (ob_get_level() === 0) {
    ob_start();
}

// Global uncaught exception handler - always returns JSON 500
set_exception_handler(function ($e) {
    error_log("Paintora Uncaught Exception: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    if (ob_get_level() > 0) {
        ob_clean();
    }
    if (!headers_sent()) {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        if ($origin === 'http://localhost:5173' || $origin === 'http://127.0.0.1:5173') {
            header("Access-Control-Allow-Origin: {$origin}");
            header('Access-Control-Allow-Credentials: true');
        }
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
        header("Content-Type: application/json; charset=UTF-8");
        http_response_code(500);
    }
    echo json_encode([
        'success' => false,
        'message' => 'Server error: ' . $e->getMessage(),
        'error'   => 'SERVER_ERROR'
    ], JSON_UNESCAPED_SLASHES);
    exit();
});

// Register shutdown function to catch fatal errors and output uniform JSON 500
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        error_log("Paintora Fatal Error: " . $error['message'] . " in " . $error['file'] . ":" . $error['line']);
        if (ob_get_level() > 0) {
            ob_clean();
        }
        if (!headers_sent()) {
            $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
            if ($origin === 'http://localhost:5173' || $origin === 'http://127.0.0.1:5173') {
                header("Access-Control-Allow-Origin: {$origin}");
                header('Access-Control-Allow-Credentials: true');
            }
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
            header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
            header("Content-Type: application/json; charset=UTF-8");
            http_response_code(500);
        }
        echo json_encode([
            'success' => false,
            'message' => 'Server error: ' . $error['message'],
            'error'   => 'SERVER_ERROR'
        ], JSON_UNESCAPED_SLASHES);
        exit();
    }
});

// Set CORS headers so React frontend can communicate with PHP API
function setCorsHeaders() {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin === 'http://localhost:5173' || $origin === 'http://127.0.0.1:5173') {
        header("Access-Control-Allow-Origin: {$origin}");
        header('Access-Control-Allow-Credentials: true');
    }
    header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
    header("Content-Type: application/json; charset=UTF-8");

    // Handle preflight OPTIONS request from browser
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        if (ob_get_level() > 0) {
            ob_clean();
        }
        http_response_code(200);
        exit();
    }
}

/**
 * Send a standardized success JSON response
 *
 * @param string $message Success message description
 * @param mixed $data Data payload (object or array)
 * @param int $statusCode HTTP status code (default 200)
 */
function sendSuccess($message, $data = null, $statusCode = 200) {
    if (ob_get_level() > 0) {
        ob_clean();
    }
    http_response_code($statusCode);
    $response = [
        'success' => true,
        'message' => $message
    ];
    if ($data !== null) {
        $response['data'] = $data;
    }
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit();
}

/**
 * Send a standardized error JSON response
 *
 * @param string $message User-friendly error message
 * @param string $errorCode Short machine-readable error identifier
 * @param int $statusCode HTTP status code (400, 404, 422, 500)
 * @param mixed $errors Optional array of field-level validation errors
 */
function sendError($message, $errorCode = 'BAD_REQUEST', $statusCode = 400, $errors = null) {
    if (ob_get_level() > 0) {
        ob_clean();
    }
    http_response_code($statusCode);
    $response = [
        'success' => false,
        'message' => $message,
        'error' => $errorCode
    ];
    if ($errors !== null) {
        $response['errors'] = $errors;
    }
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit();
}

/**
 * Helper to get JSON payload from php://input
 */
function getJsonInput() {
    $rawInput = file_get_contents('php://input');
    if (empty($rawInput)) {
        return [];
    }
    // Strip UTF-8 BOM if present
    $rawInput = preg_replace('/^\xEF\xBB\xBF/', '', $rawInput);
    $data = json_decode(trim($rawInput), true);
    return is_array($data) ? $data : [];
}
